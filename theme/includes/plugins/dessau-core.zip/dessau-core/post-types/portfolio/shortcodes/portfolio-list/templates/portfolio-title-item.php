<article class="qodef-pl-item qodef-item-space qodef-pl-title-item">
	<div class="qodef-pl-item-inner">
        <div class="qodef-pl-item-inner-wrapper">
            <h3><?php echo wp_kses_post($list_standard_title)?></h3>
        </div>
	</div>
</article>