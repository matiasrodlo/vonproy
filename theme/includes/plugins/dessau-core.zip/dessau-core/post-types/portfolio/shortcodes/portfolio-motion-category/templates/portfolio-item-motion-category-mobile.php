<article class="qodef-pl-item swiper-slide <?php echo implode( ' ', get_post_class() ); ?>">
	<?php echo dessau_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-motion-category', 'parts/image-motion-category', '', $params); ?>
	<h4 itemprop="name" class="qodef-pli-title entry-title"><?php echo esc_html( get_the_title() ); ?></h4>
</article>