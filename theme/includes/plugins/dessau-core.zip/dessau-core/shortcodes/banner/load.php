<?php

include_once DESSAU_CORE_SHORTCODES_PATH . '/banner/functions.php';
include_once DESSAU_CORE_SHORTCODES_PATH . '/banner/banner.php';