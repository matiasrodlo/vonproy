<?php

include_once DESSAU_CORE_SHORTCODES_PATH . '/image-info-section/functions.php';
include_once DESSAU_CORE_SHORTCODES_PATH . '/image-info-section/image-info-section.php';