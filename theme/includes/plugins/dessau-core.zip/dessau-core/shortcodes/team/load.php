<?php

include_once DESSAU_CORE_SHORTCODES_PATH . '/team/functions.php';
include_once DESSAU_CORE_SHORTCODES_PATH . '/team/team.php';