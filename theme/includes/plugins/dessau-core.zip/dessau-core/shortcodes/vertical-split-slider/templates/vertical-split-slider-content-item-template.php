<div class="qodef-vss-ms-section" <?php echo dessau_select_get_inline_attrs($content_data); ?> <?php dessau_select_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>