<?php if(dessau_select_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>