<?php
//OVO OBAVEZNO PROVERITI KAKO JE NA MASTERU
if(dessau_instagram_theme_installed()) {
	include_once 'dessau-instagram-widget.php';
}